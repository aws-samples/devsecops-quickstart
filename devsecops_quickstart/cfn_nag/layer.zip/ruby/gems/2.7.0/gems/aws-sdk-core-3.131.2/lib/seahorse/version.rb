# frozen_string_literal: true

module Seahorse
  VERSION = '0.1.0'
end
