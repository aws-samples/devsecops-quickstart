0.1.4 (2022-02-12)
==========

## Enhancements
* Add support for simplecov's groups feature -w [#2](https://github.com/codeclimate-community/simplecov_json_formatter/pull/2) @PragTob

0.1.3 (2021-05-02)
==========

## Bugfixes
* avoid emitting warnings when ruby is run with -w [#1](https://github.com/codeclimate-community/simplecov_json_formatter/pull/1) @flavorjones


