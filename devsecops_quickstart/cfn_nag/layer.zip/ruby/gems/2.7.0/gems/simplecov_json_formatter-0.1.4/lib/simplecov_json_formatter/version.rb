# frozen_string_literal: true

module SimpleCovJSONFormatter
  VERSION = '0.1.4'
end
