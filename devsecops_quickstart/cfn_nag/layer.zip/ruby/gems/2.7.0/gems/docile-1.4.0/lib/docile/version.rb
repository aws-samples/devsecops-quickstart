# frozen_string_literal: true

module Docile
  # The current version of this library
  VERSION = "1.4.0"
end
