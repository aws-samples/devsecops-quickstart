# frozen_string_literal: true

module SimpleCov
  # TODO: Documentation on how to build your own formatters
  module Formatter
  end
end

require_relative "formatter/simple_formatter"
require_relative "formatter/multi_formatter"
