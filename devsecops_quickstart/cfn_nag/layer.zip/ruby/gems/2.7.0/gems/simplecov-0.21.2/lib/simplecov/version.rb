# frozen_string_literal: true

module SimpleCov
  VERSION = "0.21.2"
end
