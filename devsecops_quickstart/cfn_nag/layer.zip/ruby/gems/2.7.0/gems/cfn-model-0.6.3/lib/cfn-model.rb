# frozen_string_literal: true

require 'cfn-model/parser/cfn_parser'
require 'cfn-model/model/cfn_model'