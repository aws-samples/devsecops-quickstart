# frozen_string_literal: true

require "bundler/setup"
require "simplecov"
require "simplecov-html"
require "minitest/autorun"
