module Logging
  module Filters ; end
  require libpath('logging/filters/level')
end