# frozen_string_literal: true

module SimpleCov
  module Formatter
    class HTMLFormatter
      VERSION = "0.12.3"
    end
  end
end
