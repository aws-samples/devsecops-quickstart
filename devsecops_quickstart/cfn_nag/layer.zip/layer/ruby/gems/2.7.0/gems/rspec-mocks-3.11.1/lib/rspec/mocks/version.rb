module RSpec
  module Mocks
    # Version information for RSpec mocks.
    module Version
      # Version of RSpec mocks currently in use in SemVer format.
      STRING = '3.11.1'
    end
  end
end
